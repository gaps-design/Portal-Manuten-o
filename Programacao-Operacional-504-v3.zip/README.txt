PROGRAMAÇÃO OPERACIONAL 504 — V3

Novidades:
- Base SAP inicial com 95 ordens.
- Importação direta de HTM/HTML do SAP.
- Base Operacional editável: operador, turno, grupo/célula e status Ativo/Férias.
- Operador em Férias sai da distribuição de ordens pendentes, preservando histórico executado.
- Competências mensais automáticas pela data da ordem.
- Dashboard com filtro de mês e comparação.
- Aba Histórico / Evolução mensal.
- Registro local do histórico de importações e detecção de novas confirmações CONF.

Para GitHub Pages, mantenha index.html na raiz do repositório.
